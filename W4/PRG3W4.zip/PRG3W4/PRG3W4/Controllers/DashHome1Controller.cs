﻿using Microsoft.AspNetCore.Mvc;

namespace PRG3W4.Controllers
{
    public class DashHome1Controller : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
