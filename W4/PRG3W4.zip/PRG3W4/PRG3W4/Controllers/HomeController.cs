using Microsoft.AspNetCore.Mvc;
using PRG3W4.Models;
using System.Diagnostics;

namespace PRG3W4.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        // Action INI sekarang mengalihkan pengguna dari URL utama (/)
        // ke halaman List Data Kategori.
        public IActionResult Index()
        {
            // Mengalihkan pengguna ke Action Index() di KategoriController
            // return RedirectToAction("Index", "Kategori");
            return RedirectToAction("Index", "Budget");
        }

        // Action standar untuk halaman Privacy
        public IActionResult Privacy()
        {
            return View();
        }

        // Action standar untuk penanganan Error
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            // Pastikan Anda memiliki ErrorViewModel di folder Models
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}