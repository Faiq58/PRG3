﻿// Controllers/KategoriController.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PRG3W4.Data;
using PRG3W4.Models;
using System;

public class KategoriController : Controller
{
    private readonly AppDbContext _context;

    public KategoriController(AppDbContext context)
    {
        _context = context;
    }

    // ----------------------------------------
    // C.R.U.D: READ (List Data - Index)
    // ----------------------------------------
    public async Task<IActionResult> Index()
    {
        // Mengambil semua data kategori
        return View(await _context.Kategori.ToListAsync());
    }

    // ----------------------------------------
    // C.R.U.D: CREATE (Form)
    // ----------------------------------------
    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Kategori kategori)
    {
        if (ModelState.IsValid)
        {
            _context.Add(kategori);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        return View(kategori);
    }

    // ... Implementasikan Edit(GET/POST), Details, dan Delete(GET/POST) di sini
}