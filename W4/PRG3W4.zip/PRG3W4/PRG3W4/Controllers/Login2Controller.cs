﻿using Microsoft.AspNetCore.Mvc;

namespace PRG3W4.Controllers
{
    public class Login2Controller : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
