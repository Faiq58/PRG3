﻿// Controllers/BudgetController.cs

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PRG3W4.Data;
using PRG3W4.Models;

public class BudgetController : Controller
{
    private readonly AppDbContext _context;

    public BudgetController(AppDbContext context)
    {
        _context = context;
    }

    // ----------------------------------------
    // C.R.U.D: READ (List Data - Index)
    // ----------------------------------------
    // FIX: Tambahkan <IActionResult>
    public async Task<IActionResult> Index()
    {
        var budgets = _context.Budget.Include(b => b.Kategori);
        return View(await budgets.ToListAsync());
    }

    // ----------------------------------------
    // C.R.U.D: CREATE (Form) - GET
    // ----------------------------------------
    public IActionResult Create()
    {
        ViewBag.KategoriId = new SelectList(_context.Kategori.Where(k => k.Status == "Active"), "Id", "Nama");
        return View();
    }

    // ----------------------------------------
    // C.R.U.D: CREATE (Form) - POST
    // ----------------------------------------
    [HttpPost]
    [ValidateAntiForgeryToken]
    // FIX: Tambahkan <IActionResult>
    public async Task<IActionResult> Create(Budget budget)
    {
        if (ModelState.IsValid)
        {
            _context.Add(budget);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        ViewBag.KategoriId = new SelectList(_context.Kategori.Where(k => k.Status == "Active"), "Id", "Nama", budget.KategoriId);
        return View(budget);
    }

    // U - Update (Melihat Form)
    public async Task<IActionResult> Edit(int? id)
    {
        if (id == null) return NotFound();

        var budget = await _context.Budget.FindAsync(id);
        if (budget == null) return NotFound();

        // Muat ulang daftar kategori untuk dropdown
        ViewBag.KategoriId = new SelectList(_context.Kategori.Where(k => k.Status == "Active"), "Id", "Nama", budget.KategoriId);
        return View(budget);
    }

    // U - Update (Menyimpan perubahan)
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, [Bind("Id,KategoriId,Nama,Deskripsi,TotalBudget,StartDate,EndDate,IsRepeat,Status")] Budget budget)
    {
        if (id != budget.Id) return NotFound();

        if (ModelState.IsValid)
        {
            try
            {
                _context.Update(budget);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Budget.Any(e => e.Id == id)) return NotFound();
                else throw;
            }
            return RedirectToAction(nameof(Index));
        }
        ViewBag.KategoriId = new SelectList(_context.Kategori.Where(k => k.Status == "Active"), "Id", "Nama", budget.KategoriId);
        return View(budget);
    }
    // R - Read (Details)
    public async Task<IActionResult> Details(int? id)
    {
        if (id == null) return NotFound();

        var budget = await _context.Budget
            .Include(b => b.Kategori) // Pastikan data relasi dimuat
            .FirstOrDefaultAsync(m => m.Id == id);

        if (budget == null) return NotFound();

        return View(budget);
    }
    // D - Delete (Konfirmasi Hapus)
    public async Task<IActionResult> Delete(int? id)
    {
        if (id == null) return NotFound();

        var budget = await _context.Budget
            .Include(b => b.Kategori)
            .FirstOrDefaultAsync(m => m.Id == id);

        if (budget == null) return NotFound();

        return View(budget);
    }

    // D - Delete (Proses Hapus)
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var budget = await _context.Budget.FindAsync(id);
        if (budget != null)
        {
            _context.Budget.Remove(budget);
            await _context.SaveChangesAsync();
        }
        return RedirectToAction(nameof(Index));
    }
}