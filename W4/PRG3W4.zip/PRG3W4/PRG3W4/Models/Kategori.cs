﻿// Models/Kategori.cs
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PRG3W4.Models
{
    public class Kategori
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required(ErrorMessage = "Tipe harus diisi.")]
        public string Tipe { get; set; } = null!;

        [Required(ErrorMessage = "Nama Kategori harus diisi.")]
        [StringLength(100)]
        public string Nama { get; set; } = null!;

        public string? Deskripsi { get; set; } // Dibuat nullable

        [Required]
        public string Status { get; set; } = null!;
    }
}