﻿// Models/Budget.cs
using System.ComponentModel.DataAnnotations; // Wajib
using System.ComponentModel.DataAnnotations.Schema; // Wajib

namespace PRG3W4.Models
{
    public class Budget
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Display(Name = "Kategori")]
        public int KategoriId { get; set; } 

        public Kategori Kategori { get; set; } = null!;

        [Required(ErrorMessage = "Nama Budget harus diisi.")]
        [StringLength(100)]
        public string Nama { get; set; } = null!;

        public string? Deskripsi { get; set; } // Dibuat nullable

        [Required]
        [Column(TypeName = "decimal(18, 2)")]
        [Display(Name = "Total Budget")]
        public decimal TotalBudget { get; set; }

        [Required(ErrorMessage = "Tanggal Mulai harus diisi.")]
        [DataType(DataType.Date)] // DataType
        [Display(Name = "Tanggal Mulai")]
        public DateTime StartDate { get; set; }

        [Required(ErrorMessage = "Tanggal Selesai harus diisi.")]
        [DataType(DataType.Date)] // DataType
        [Display(Name = "Tanggal Selesai")]
        public DateTime EndDate { get; set; }

        [Display(Name = "Ulangi?")]
        public bool IsRepeat { get; set; }

        [Required]
        public string Status { get; set; } = null!;
    }
}