﻿// Data/AppDbContext.cs (Contoh)
using Microsoft.EntityFrameworkCore;
using PRG3W4.Models;
using System.Collections.Generic;

namespace PRG3W4.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        // Tambahkan kedua DbSet
        public DbSet<Kategori> Kategori { get; set; }
        public DbSet<Budget> Budget { get; set; }
    }
}