﻿using Microsoft.AspNetCore.Mvc;

namespace PRG3W3.Controllers // Ganti namespace sesuai nama project Anda
{
    public class DashboardController : Controller
    {
        public IActionResult Dash()
        {
            return View(); 
        }
    }
}