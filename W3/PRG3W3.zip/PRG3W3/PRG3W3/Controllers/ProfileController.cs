﻿using Microsoft.AspNetCore.Mvc;

namespace PRG3W3.Controllers
{
    // Anda bisa menambahkan Route jika ingin mengubah URL-nya,
    // contohnya menjadi [Route("user-profile")]
    public class ProfileController : Controller
    {
        // Action ini akan merespons permintaan ke /Profile
        public IActionResult Identity()
        {
            return View("Identity");
        }

        // Anda bisa menambahkan action lain untuk proses update profil, contoh:
        // [HttpPost]
        // public IActionResult UpdateProfile(ProfileViewModel model)
        // {
        //     // ... logika update data
        //     return RedirectToAction("Index");
        // }
    }
}