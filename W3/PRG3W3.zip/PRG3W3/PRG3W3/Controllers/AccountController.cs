﻿using Microsoft.AspNetCore.Mvc;

namespace PRG3W3.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Login()
        {
            return View(); 
        }

        [HttpPost]
        public IActionResult Login(string Username, string Password)
        {
            if (Username == "a" && Password == "a")
            {
                return RedirectToAction("Dash2", "Dashboard");
            }
            else
            {
                ViewData["ErrorMessage"] = "Nama pengguna atau kata sandi salah.";
                return View();
            }
        }
    }
}