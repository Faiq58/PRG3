using System.Diagnostics;
using PRG3W3.Models;
using Microsoft.AspNetCore.Mvc;

namespace PRG3W3.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        // Action INI akan diakses secara default oleh routing (jika Program.cs tidak diubah).
        // Kita ubah agar Action ini langsung MENGALIHKAN pengguna ke halaman Login.
        public IActionResult Index()
        {
            // Mengalihkan pengguna ke Action Login di AccountController.
            return RedirectToAction("Login", "Account");
        }

        // Action standar untuk halaman Privacy
        public IActionResult Privacy()
        {
            return View();
        }
        // Action standar untuk penanganan Error
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            // Asumsikan Anda memiliki ErrorViewModel di folder Models
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}